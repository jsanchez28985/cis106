# What is Markdown?
    Markdown is a markup language that lets you write plain text documents with a few lightweight formatting options. 
# What is Git?
    Git is a free open-source software that keeps track of files that can be edited by multiple people at the same time.
# What is GitHub?
    GitHub is a cloud storage that is built on Git and lets users share as well as edit code.
# What is Slack?
    Slack is an online communications software that allows the user to create a workspace chat and invite others.
